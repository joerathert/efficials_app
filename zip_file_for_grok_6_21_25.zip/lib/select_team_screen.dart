import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'theme.dart';

class SelectTeamScreen extends StatefulWidget {
  const SelectTeamScreen({super.key});

  @override
  State<SelectTeamScreen> createState() => _SelectTeamScreenState();
}

class _SelectTeamScreenState extends State<SelectTeamScreen> {
  String? _selectedSport;
  String? _selectedGrade;
  String? _selectedGender;
  final List<String> _sports = [
    'Baseball',
    'Basketball',
    'Football',
    'Soccer',
    'Softball',
    'Volleyball',
  ]; // Assumed from select_sport_screen.dart
  final List<String> _grades = [
    '6U', '7U', '8U', '9U', '10U', '11U', '12U', '13U', '14U', '15U', '16U', '17U', '18U', 'Adult'
  ];
  List<String> _genders = ['Boys', 'Girls', 'Co-ed'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: efficialsBlue,
        title: const Text('Set Up Team', style: appBarTextStyle),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 40),
                DropdownButtonFormField<String>(
                  decoration: textFieldDecoration('Sport'),
                  value: _selectedSport,
                  items: _sports.map((sport) => DropdownMenuItem(value: sport, child: Text(sport))).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedSport = value;
                    });
                  },
                ),
                const SizedBox(height: 20),
                DropdownButtonFormField<String>(
                  decoration: textFieldDecoration('Grade Level'),
                  value: _selectedGrade,
                  items: _grades.map((grade) => DropdownMenuItem(value: grade, child: Text(grade))).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedGrade = value;
                      _selectedGender = null; // Reset gender
                      _genders = value == 'Adult' ? ['Men', 'Women', 'Co-ed'] : ['Boys', 'Girls', 'Co-ed'];
                    });
                  },
                ),
                const SizedBox(height: 20),
                DropdownButtonFormField<String>(
                  decoration: textFieldDecoration('Gender'),
                  value: _selectedGender,
                  items: _genders.map((gender) => DropdownMenuItem(value: gender, child: Text(gender))).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedGender = value;
                    });
                  },
                ),
                const SizedBox(height: 30),
                ElevatedButton(
                  onPressed: () async {
                    if (_selectedSport == null || _selectedGrade == null || _selectedGender == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Please select all fields')),
                      );
                      return;
                    }
                    final teamName = '$_selectedSport $_selectedGender $_selectedGrade';
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.setString('coach_team', teamName);
                    Navigator.pop(context);
                  },
                  style: elevatedButtonStyle(),
                  child: const Text('Continue', style: signInButtonTextStyle),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}